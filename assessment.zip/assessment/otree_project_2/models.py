from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
)

class Constants(BaseConstants):
    name_in_url = 'exit_survey'
    players_per_group = None
    num_rounds = 1

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    pass

class Player(BasePlayer):
    q1_capital_city = models.StringField(
        label="What is the capital City of Kenya?",
        choices=[
            'Kisumu',
            'Nairobi',
            'Mombasa',
        ],
        widget=widgets.RadioSelect
    )
    q2_math = models.IntegerField(
        label="What is 14 + 15 ?",
    )
    q3_population = models.IntegerField(
        label="What is the population of Kenya? (Input a number)"
    )
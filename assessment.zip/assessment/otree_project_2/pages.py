from otree.api import Page, WaitPage
from .models import Constants

class Q1(Page):
    form_model = 'player'
    form_fields = ['q1_capital_city']

class Q2(Page):
    form_model = 'player'
    form_fields = ['q2_math']

    def error_message(self, values):
        # Assuming the correct answer is 29
        if values['q2_math'] != 29:
            return 'This answer is incorrect, please try again.'

class Q3(Page):
    form_model = 'player'
    form_fields = ['q3_population']

page_sequence = [Q1, Q2, Q3]

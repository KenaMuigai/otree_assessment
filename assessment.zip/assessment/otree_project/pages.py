from otree.api import Currency as cu, currency_range
from .models import Constants
from ._builtin import Page, WaitPage

class Send(Page):
    form_model = 'group'
    form_fields = ['sent_amount']

    def is_displayed(self):
        self.group.save()
        return self.player.id_in_group == 1

class PunishDecision(Page):
    form_model = 'group'
    form_fields = ['punish_decision']

    def is_displayed(self):
        return self.player.id_in_group == 3

class ResultsWaitPage(WaitPage):
    after_all_players_arrive = 'set_payoffs'

class Results(Page):
    def vars_for_template(self):
        group = self.group
        # player = self.player
        print('DEBUG: sent_amount is', group.sent_amount)  # Debug print

        return {
            'sent_amount': group.sent_amount,
            'punish_decision': "Punish" if group.punish_decision else "Not Punish",
            'player_payout': self.player.payout,
        }

    # def is_displayed(self):
    #     return self.player.id_in_group in [1, 2]

page_sequence = [Send, PunishDecision, ResultsWaitPage, Results]
from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as cu, currency_range
)

class Constants(BaseConstants):
    name_in_url = 'ultimatum_game'
    players_per_group = 3
    num_rounds = 1
    endowment = cu(200)

class Subsession(BaseSubsession):
    pass

class Group(BaseGroup):
    sent_amount = models.CurrencyField(
        min=0, 
        max=Constants.endowment, 
        sent_amount = models.CurrencyField()
        doc="Amount sent by Player 1"
    )
    punish_decision = models.BooleanField(
        doc="Punish decision by Player 3"
    )

    def set_payoffs(self):
        p1 = self.get_player_by_id(1)
        p2 = self.get_player_by_id(2)
        p3 = self.get_player_by_id(3)

        if self.punish_decision:
            p1.payout = cu(0)
            p2.payout = cu(0)
        else:
            p1.payout = Constants.endowment - self.sent_amount
            p2.payout = self.sent_amount

class Player(BasePlayer):
    payout = models.CurrencyField(initial=0)